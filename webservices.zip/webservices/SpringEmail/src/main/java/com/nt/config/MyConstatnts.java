package com.nt.config;

public class MyConstatnts {

	//public static final String MY_EMAIL="srinivasyerru@gmail.com";
	//public static final String MY_PASSWORD="Window@2021";
	
	public static final String MY_EMAIL="AU-Technical-DoNotReply-OutgoingEmails@dbschenker.com";
	public static final String MY_PASSWORD="Outg0!n$";
	
	//public static final String FRIEND_EMAIL="srinvsyerru@gmail.com";
	public static final String FRIEND_EMAIL="srinivasa.rao-extern@dbschenker.com";
	
	
}
