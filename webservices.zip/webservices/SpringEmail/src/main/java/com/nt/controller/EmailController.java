package com.nt.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmailController {

	@Autowired
	private SendEmail sendEmail;
	
	
	@Autowired
	HttpServletRequest request;

	@GetMapping(path = "/api/probconf/email",  produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getEmailDetails1() {
		EmailDetails emailDetails=new EmailDetails();
		emailDetails.setToMail("srinivasa.rao-extern@dbschenker.com");
		emailDetails.setEmailMessage("test mesage");
		emailDetails.setCc("srinivasa.rao-extern@dbschenker.com");
		emailDetails.setSubject("welcome test");
		sendEmail.sendMailQuote(emailDetails.getToMail(), emailDetails.getEmailMessage(), emailDetails.getCc(), emailDetails.getSubject());

		EmailDetails ed=new EmailDetails();
		
		InetAddress ip = null;
	      try {

	        ip = InetAddress.getLocalHost();
	        System.out.println("Current IP address : " + ip.getHostAddress());
            System.out.println("host name"+ip.getHostName());
            System.out.println("InetAddress.getLocalHost().getHostAddress()::"+InetAddress.getLocalHost().getHostAddress());

            System.out.println("InetAddress.getLocalHost().getHostAddress()::"+InetAddress.getLocalHost().getHostName());

            System.out.println("InetAddress.getLocalHost().getHostAddress()::"+InetAddress.getLocalHost().getAddress());

				ed.setIp(ip.getHostAddress());
			System.out.println("inetadress :: "+ip);
			System.out.println("Host Name"+ip.getHostName());
			System.out.println(" getCanonicalHostName"+ip.getCanonicalHostName());
			System.out.println(" getAddress"+ip.getAddress());
			System.out.println("getLocalHost "+ip.getLocalHost());
			try {

				System.out.println("innternet address cc "+InternetAddress.parse(emailDetails.getCc()));
			    System.out.println("internet address to :: "+InternetAddress.parse(emailDetails.getToMail()));
			//HttpServletRequest request = null;
			Map<String, String> result = new HashMap<>();

	        Enumeration headerNames = request.getHeaderNames();
	        while (headerNames.hasMoreElements()) {
	            String key = (String) headerNames.nextElement();
	            String value = request.getHeader(key);
	            result.put(key, value);
	            System.out.println("result.put(key, value) :: "+result.put(key, value));
	        }
	        System.out.println("requst"+request.getRequestURI());
	        System.out.println("request.getRemoteAddr(): "+request.getRemoteAddr());
	        System.out.println("request.getRemoteHost(): "+request.getRemoteHost());
	        		
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


	      } catch (UnknownHostException e) {

	        e.printStackTrace();

	      }
		
		return ResponseEntity.status(HttpStatus.OK).body("Email Sent");
	}
	
	@GetMapping(path = "/api/probconf/test", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> getEmailDetails() {
		return ResponseEntity.status(HttpStatus.OK).body("Links are working");
	}

}
