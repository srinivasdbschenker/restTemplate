package com.nt.controller;

import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

//@ConfigurationProperties(prefix="email")
@Configuration
public class EmailProperties {
  
	 @Value("${email.simsid}")
  private String simsid;
	 @Value("${email.password}") 
  private String password;
  @Value("{email.mail}")
  private String mail;
  
  private String tomail;
  
  private String tocc;
  @Value("${email.port}")
  private String port;
  @Value("${email.host}")
  private String host;
 
  private String body;
  
  private String subject;
  
  
  public String getSimsid() {
    return simsid;
  }
  public void setSimsid(String simsid) {
    this.simsid = simsid;
  }
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }
  public String getMail() {
    return mail;
  }
  public void setMail(String mail) {
    this.mail = mail;
  }
  public String getTomail() {
    return tomail;
  }
  public void setTomail(String tomail) {
    this.tomail = tomail;
  }
  public String getTocc() {
    return tocc;
  }
  public void setTocc(String tocc) {
    this.tocc = tocc;
  }
  public String getPort() {
    return port;
  }
  public void setPort(String port) {
    this.port = port;
  }
  public String getHost() {
    return host;
  }
  public void setHost(String host) {
    this.host = host;
  }
  public String getBody() {
    return body;
  }
  public void setBody(String body) {
    this.body = body;
  }
  public String getSubject() {
    return subject;
  }
  public void setSubject(String subject) {
    this.subject = subject;
  }
  
}