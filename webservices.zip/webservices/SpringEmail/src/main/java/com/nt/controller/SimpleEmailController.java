package com.nt.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nt.config.MyConstatnts;

@Controller
public class SimpleEmailController {

	@Autowired
	public JavaMailSender emailSender;
	
	@Autowired
	HttpServletRequest request;

	
	
	@ResponseBody
	@RequestMapping("/")
	public String welcome() {
		return "welcome";
	}
	
	@ResponseBody
	@RequestMapping("/sendSimpleEmail")
	public String sendSimpleEmail() {
		SimpleMailMessage message= new SimpleMailMessage();
		message.setTo(MyConstatnts.FRIEND_EMAIL);
		message.setSubject("Hello im testing simple email");
		message.setText("Hello, Im Testing Simple Email");
		
		this.emailSender.send(message);
		return "EmailSent";
		
	}
	@ResponseBody
	@RequestMapping("/sendSMTPEmail")
	public String sendSmtp() {
		// change accordingly 
				final String username = "TANGGIT1"; 
				
				// change accordingly 
				final String password = "Outg0!n$"; 
				
				// or IP address 
				final String host = "smtp.signintra.com"; 
				final int port=25;

				Properties props = new Properties();
				props.put("mail.smtp.auth", "true");
				props.put("mail.smtp.host", host);
				props.put("mail.smtp.port", port);
				//props.put("mail.smtp.ssl.enable", "true");


				// Get system properties 
				//Properties props = new Properties();			 
				
				// enable authentication 
				//props.put("mail.smtp.auth", host);			 
				
				// enable STARTTLS 
				//props.put("mail.smtp.starttls.enable", "false");
				
				//ssl3 TLSv1.2
				//props.put("mail.smtp.ssl.protocols", "SSLv3 TLSv1");
				
				// Setup mail server 
				//props.put("mail.smtp.host", "smtp.signintra.com");	 
				
				// TLS Port 
				//props.put("mail.smtp.port", "25");			
				//System.out.println(System.getProperties() );

				// creating Session instance referenced to 
				// Authenticator object to pass in 
				// Session.getInstance argument 
				Session session = Session.getInstance(props, 
				new javax.mail.Authenticator() { 
					
					//override the getPasswordAuthentication method 
					protected PasswordAuthentication 	getPasswordAuthentication() { 
												
						return new PasswordAuthentication(username, password); 
					} 
				}); 

				try { 
					
					// compose the message 
					// javax.mail.internet.MimeMessage class is 
					// mostly used for abstraction. 
					Message message = new MimeMessage(session);	 
					
					// header field of the header. 
					message.setFrom(new InternetAddress("srinivasa.rao-extern@dbschenker.com")); 
					
					message.setRecipients(Message.RecipientType.TO, 
						InternetAddress.parse("srinivasa.rao-extern@dbschenker.com")); 
					message.setSubject("hello"); 
					message.setText("Yo it has been sent"); 
		            
					Transport.send(message);		 //send Message 

					System.out.println("Done"); 

				} catch (MessagingException e) { 
					throw new RuntimeException(e); 
				} 

				return "hi";
	}
	
		
}
