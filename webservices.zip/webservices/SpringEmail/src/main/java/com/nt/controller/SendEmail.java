package com.nt.controller;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;


@Configuration
public class SendEmail  {

	@Autowired
	private EmailProperties emailProps;

	private final Logger log = LoggerFactory.getLogger(SendEmail.class);

	public void sendMailQuote(String toMail, String emailMessage, String cc, String subject) {




		String from = emailProps.getMail();//change accordingly
		final String username = emailProps.getSimsid();//change accordingly
		final String password = emailProps.getPassword();//change accordingly

		// Assuming you are sending email through relay.jangosmtp.net
		String host = emailProps.getHost();

		String to = toMail;
		//String cc = emailProps.getTocc();

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		//props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "25");
		props.put("mail.smtp.ssl.enable", "true");

		// Get the Session object.
		//  Session session = Session.getInstance(props, null);
		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
		session.setDebug(true);
		try {
			// Create a default MimeMessage object.
			Message message = new MimeMessage(session);
			//String subject = emailProps.getSubject();
			//String subject=sub;
			if (subject.contains("\r") || subject.contains("\n"))
				log.info("Invalid arguments found. Mail cannot be sent. Check with admin.");
			//message.setSubject(emailProps.getSubject());
			System.out.println("subject :: "+subject);

			message.setSubject(subject);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));


			// Set To: header field of the header.
			if (to != null) {
				message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			System.out.println("Message.RecipientType.TO:: "+Message.RecipientType.TO);
			}



			if (cc != null) {
				String[] ccmails=cc.split(",");
				for(String ccmail:ccmails)
					message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(ccmail));
			System.out.println("Message.RecipientType.CC:: "+Message.RecipientType.CC);
			}
			// Set Subject: header field



			// Now set the actual message
			Multipart multipart = new MimeMultipart();
			// create the message part
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setText(emailMessage, "ASCII", "html");
			// Add message part to multipart
			multipart.addBodyPart(messageBodyPart);
			message.setContent(multipart);
			  System.out.println("--------------------------------------------");
		  		System.out.println("seesion properties in send email"+session.getProperties());

		  		System.out.println("--------------------------------------------");

					// Send message
			Transport.send(message);
			  System.out.println("--------------------------------------------");
		  		System.out.println("seesion properties in send email"+session.getProperties());

		  		System.out.println("--------------------------------------------");


		} catch (MessagingException e) {
			log.info("Exception caught while sending email - ",e);;
		}

	}

}
