package com.nt.controller;

import java.net.InetAddress;


//@Entity
//@Audited
public class EmailDetails {
	//@Id
	//@GeneratedValue
	private int sid;
	private String toMail;
	private String emailMessage;
	private String cc;
	private String subject;
	String ip;
	
	
	public String getIp() {
		return ip;
	}
	public void setIp(String string) {
		this.ip = string;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getToMail() {
		return toMail;
	}
	public void setToMail(String toMail) {
		this.toMail = toMail;
	}
	public String getEmailMessage() {
		return emailMessage;
	}
	public void setEmailMessage(String emailMessage) {
		this.emailMessage = emailMessage;
	}
	public String getCc() {
		return cc;
	}
	public void setCc(String cc) {
		this.cc = cc;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	@Override
	public String toString() {
		return "EmailDetails [toMail=" + toMail + ", emailMessage=" + emailMessage + ", cc=" + cc + ", subject="
				+ subject + "]";
	}
	
}
