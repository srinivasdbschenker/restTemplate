package com.nt.controller;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@Controller
public class Welcome {

	// static final String url="http://localhost:8085/api/probconf/get-all-training-list";
static final String url="https://www.youtube.com/watch?v=h2IO8s447G8&list=RDMMh2IO8s447G8&start_radio=1";
	//@GetMapping(path = "/api/probconf/get-all-training-list", consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)

	@GetMapping(path = "/hello", consumes = MediaType.ALL_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public String helloMsg() {
		RestTemplate restTemplate=new RestTemplate();
		String result=restTemplate.getForObject(url, String.class);
		return "Hello welcome to Spring boot rest api"+"\n"+"\n--------------\n"+result;
	}

	@PostMapping(path="/hellomsgs")
	public String helloMsgs() {
		return "Hello welcome to postmapping spring boot rest api";
	}
}
